#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int * del(int *a,int size) {
	int i,j=0;
	int *b;
	b=(int *) malloc(size*sizeof(int));
	int num;
	printf("\n Enter the element to be deleted:");
	scanf("%d",&num);

	bool flag=false;
	for(i=0;i<size;i++) {
		if(*(a+i)!=num) {
			*(b+j)=*(a+i);
			j++;
			flag=true;
		}
	}
	if(!flag)
		printf("\n Element could not be found!");
	/*else{
	printf("\n After deleting: ");
	for(i=0;i<size-1;i++)
		printf("%d ",*(b+i));
	}*/
	return b;
}//end of del()......

