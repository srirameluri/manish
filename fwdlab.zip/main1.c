#include <stdio.h>
#include <stdlib.h>

#include "numprocess.h"

void main() {
	int size;
	printf("\n Enter the size:");
	scanf("%d",&size);

	int *p;
	p=(int *)malloc(sizeof(int)*size);

	printf("Enter the elements one by one:\n");
	for(int i=0;i<size;i++)
		scanf("%d",(p+i));

	int choice;
	printf("\n Instructions:");
	printf("\n Enter 1 to sort");
	printf("\n Enter 2 to search");
	printf("\n Enter 3 to delete");
	printf("\n Enter 4 to insert\n");
	scanf("%d",&choice);

	switch(choice) {
		case 1:	bub_sort(p,size);
				break;
		
		case 2: bub_sort(p,size);
				binary(p,size);
				break;
		
		case 3: p=del(p,size);
				break;
		
		case 4: p=ins(p,size);
				break;
		
		default: printf("\n Wrong choice!");
	}
	if(choice==3 || choice==4){
	printf("\n New Array: ");
	for(int i=0;i<size;i++)
		printf("%d ",*(p+i));
	}

	printf("\n");
}
