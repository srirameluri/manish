extern void bub_sort();
extern void binary();
extern int *del();
extern int * ins();

