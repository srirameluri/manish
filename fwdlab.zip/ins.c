#include <stdio.h>
#include <stdlib.h>

int * ins (int *a,int size) {
	int i,j=0;
	int *b;
	b=(int *) malloc((size+1)*sizeof(int));

	int num,pos;

	printf("\n Enter the element to be inserted:");
	scanf("%d",&num);
	printf("\n Ente the position for %d:",num);
	scanf("%d",&pos);

	for(i=0;i<size;i++) {
		if(i!=pos) {
			*(b+j)=*(a+i);
			j++;
		}
		else {
			*(b+j)=num;	
			j++;
			*(b+j)=*(a+i);
			j++;
		}
	}
	return b;
	/*printf("\n After inserting: ");
	for(i=0;i<size+1;i++)
		printf("%d ",*(b+i));*/
}//end of del()......

