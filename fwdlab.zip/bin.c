#include <stdio.h>
#include <stdbool.h>


void binary(int *a,int size) {

	int s;
	printf("\n Enter the element to be searched:");
	scanf("%d",&s);

	int i,j;
	int first=0,last=size-1,mid;
	bool flag=false;

	for(i=0;i<size;i++) {
		mid=(first+last)/2;
		if(*(a+mid)<s)
			first=mid+1;
		if(*(a+mid)>s)
			last=mid-1;
		if(*(a+mid)==s) {
			flag=true;
			break;
		}
	}
	if(flag)
		printf("\n Number found..");
	else
		printf("\n Number could not be found!");
}


