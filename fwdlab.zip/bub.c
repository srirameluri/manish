#include <stdio.h>

void bub_sort(int *a,int size) {
	int i,j,temp;

	for(i=0;i<size-1;i++) {
		for(j=i+1;j<size;j++) {
			if(*(a+i)>*(a+j)) {
				temp=*(a+j);
				*(a+j)=*(a+i);
				*(a+i)=temp;
			}
		}
	}
	printf("\n After sorting: ");
	for(i=0;i<size;i++)
		printf("%d ",*(a+i));
}

